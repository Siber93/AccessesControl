# esp8266_mdns test program.
This is a sample program using the esp8266_mdns library.
It queries the network for hosts providing the service defined in QUESTION_SERVICE.
Any answers are parsed and stored, hopefully providing you with the port and ipv4 network address of all hosts on the network providing the service.
See https://github.com/mrdunk/esp8266_mdns for more information on the library and mDNS in general.
